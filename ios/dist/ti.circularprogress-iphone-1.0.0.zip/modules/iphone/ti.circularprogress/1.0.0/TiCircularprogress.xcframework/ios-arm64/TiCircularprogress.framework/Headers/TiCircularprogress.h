//
//  TiCircularprogress.h
//  ti.circularprogress
//
//  Created by Your Name
//  Copyright (c) 2021 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiCircularprogress.
FOUNDATION_EXPORT double TiCircularprogressVersionNumber;

//! Project version string for TiCircularprogress.
FOUNDATION_EXPORT const unsigned char TiCircularprogressVersionString[];

#import "TiCircularprogressModuleAssets.h"
